@include('partials.customer_header')
@yield('content')
@include('partials.customer_footer')
