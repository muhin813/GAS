<h2>{{App\Common::SITE_TITLE}}</h2>
Your registration have been completed. <br>
After login use {{$otp}} as OTP to verify your account <br>
