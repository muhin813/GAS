Your account have been created successfully. <br>
User Details <br>
<table>
    <tr style="text-align: left;">
        <th>User Id</th>
        <th>{{$user->id}}</th>
    </tr>
    <tr style="text-align: left;">
        <th>Name</th>
        <th>{{$user->name}}</th>
    </tr>
    <tr style="text-align: left;">
        <th>Email</th>
        <th>{{$user->email}}</th>
    </tr>
    <tr style="text-align: left;">
        <th>Password</th>
        <th>{{$user->password}}</th>
    </tr>
    <tr style="text-align: left;">
        <th>Phone</th>
        <th>{{$user->phone}}</th>
    </tr>
</table>
