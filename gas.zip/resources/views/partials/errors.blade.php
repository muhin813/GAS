<div class="alert alert-success success_message" id="success_message" style="display:none"></div>
<div class="alert alert-danger error_message" id="error_message" style="display: none"></div>