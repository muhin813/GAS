@extends('layouts.master')
@section('title', 'Create Cash Book')
@section('content')

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->
            <!-- BEGIN PAGE BAR -->
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <a href="{{url('/')}}">Home</a>
                        <i class=""></i>
                    </li>
                    <li>
                        <a href="{{url('cash_books')}}">Cash Books</a>
                        <i class=""></i>
                    </li>
                    <li>
                        <span>Create</span>
                    </li>
                </ul>
                <div class="page-toolbar">

                </div>
            </div>

            <!-- BEGIN PAGE TITLE-->
            <!-- <h3 class="page-title"> Projects
                <small>dashboard &amp; statistics</small>
            </h3> -->
            <!-- END PAGE TITLE-->
            <!-- END PAGE BAR -->
            <!-- END PAGE HEADER-->

            <div class="row mt-3">
                <div class="col-md-12">
                    <form  id="cash_book_form" method="post" action="" enctype="multipart/form-data">
                        {{csrf_field()}}
                        <div class="alert alert-success" id="success_message" style="display:none"></div>
                        <div class="alert alert-danger" id="error_message" style="display: none"></div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN PORTLET -->
                                <div class="portlet light ">
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for=""><b>Date</b></label>
                                                    <input type="text" class="form-control datepicker" name="date" id="date" value="" autocomplete="off">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for=""><b>Debit Party</b></label>
                                                    <input type="text" class="form-control" name="debit_party" id="debit_party" value="" >
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for=""><b>Credit Party</b></label>
                                                    <input type="text" class="form-control" name="credit_party" id="credit_party" value="" >
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for=""><b>Amount</b></label>
                                                    <input type="number" class="form-control" name="amount" id="amount" value="" >
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for=""><b>Narration</b></label>
                                                    <input type="text" class="form-control" name="narration" id="narration" value="" >
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group text-right">
                                            <button type="submit" class="btn green submit-btn" id="profile_button">Save</button>
                                        </div>
                                    </div>
                                </div>
                                <!-- END PORTLET -->
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->

@endsection

@section('js')

    <script>
        $(document).ready(function(){

        });

        $(document).on("submit", "#cash_book_form", function(event) {
            event.preventDefault();
            show_loader();

            var date = $("#date").val();
            var debit_party = $("#debit_party").val();
            var credit_party = $("#credit_party").val();
            var amount = $("#amount").val();

            var validate = "";

            if (date.trim() == "") {
                validate = validate + "Date is required</br>";
            }
            if (debit_party.trim() == "") {
                validate = validate + "Debit party is required</br>";
            }
            if (credit_party.trim() == "") {
                validate = validate + "Credit party is required</br>";
            }
            if (debit_party.trim() != "cash" && debit_party.trim() != "Cash" && credit_party.trim() != "cash" && credit_party.trim() != "Cash") {
                validate = validate + "Either debit party or credit party must have a value named as 'Cash'</br>";
            }
            if (amount.trim() == "") {
                validate = validate + "Amount is required</br>";
            }

            if (validate == "") {
                var formData = new FormData($("#cash_book_form")[0]);
                var url = "{{ url('cash_books/store') }}";

                $.ajax({
                    type: "POST",
                    url: url,
                    data: formData,
                    success: function(data) {
                        hide_loader();
                        if (data.status == 200) {
                            $('#cash_book_form')[0].reset();

                            $("#success_message").show();
                            $("#error_message").hide();
                            $("#success_message").html(data.reason);
                            setTimeout(function(){
                                window.location.href="{{url('cash_books')}}";
                            },1000)
                        } else {
                            $("#success_message").hide();
                            $("#error_message").show();
                            $("#error_message").html(data.reason);
                        }
                    },
                    error: function(data) {
                        hide_loader();
                        $("#success_message").hide();
                        $("#error_message").show();
                        $("#error_message").html(data);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
            } else {
                hide_loader();
                $("#success_message").hide();
                $("#error_message").show();
                $("#error_message").html(validate);
            }
        });
    </script>
@endsection

