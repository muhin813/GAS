<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemUom extends Model
{
    protected $guarded = [];
}
