<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SalesServiceCostingDetail extends Model
{
    protected $guarded = [];
}
