<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PartyCategory extends Model
{
    protected $guarded = [];
}
